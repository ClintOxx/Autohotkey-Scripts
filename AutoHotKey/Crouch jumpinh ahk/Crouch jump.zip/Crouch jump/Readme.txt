Change the F2 keybinding to whatever secomdary key you have set as jump 
Change E to whatever your crouch key is 
or just change your keys in game to match the script